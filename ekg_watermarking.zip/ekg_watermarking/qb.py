# ============================================================
# QB (QIM) METODA - UMETANJE, EKSTRAKCIJA I SLIKE
# Kvantizacija A4 koeficijenata (db4, 4 nivoa) sa dither
# vrijednostima 0 i delta/2; slijepa ekstrakcija.
# ============================================================

import numpy as np
import pywt
import matplotlib.pyplot as plt

from zajednicko import to_bits, save_figure

FIGURE_NUMBER = 8   # broj slike razlike koeficijenata u radu
NAME = "QB"
WAVELET = "db4"
LEVEL = 4
DELTA = 2.2497   # korak kvantizacije, kalibrisan na PSNR = 60 dB


def embed(ecg_signal, watermark, delta=DELTA, fs=1000):
    """QIM umetanje: A4_wm = round((A4 - d) / delta) * delta + d."""

    coeffs = pywt.wavedec(ecg_signal, WAVELET, level=LEVEL)
    original_A4 = coeffs[0].copy()

    # Binarni vodeni žig prilagođen broju A4 koeficijenata
    reference = np.resize(watermark, original_A4.shape)
    reference_bits = to_bits(reference)

    # Dither: 0 za bit 0, delta/2 za bit 1
    dither = np.where(reference_bits == 0, 0.0, delta / 2)

    watermarked_A4 = np.round((original_A4 - dither) / delta) * delta + dither
    coeffs[0] = watermarked_A4

    watermarked_signal = pywt.waverec(coeffs, WAVELET)[:len(ecg_signal)]

    state = dict(
        name=NAME, binary=True, delta=delta,
        param=f"Δ = {delta}",
        original_A4=original_A4,
        watermarked_A4=watermarked_A4,
        reference=reference,
        reference_bits=reference_bits,
        capacity=len(reference_bits),
        element_label="Indeks A4 koeficijenta",
    )
    return watermarked_signal, state


def extract(signal, state):
    """Slijepa ekstrakcija: bit određuje bliža kvantizaciona mreža."""
    delta = state["delta"]
    attacked_A4 = pywt.wavedec(signal, WAVELET, level=LEVEL)[0]

    q0 = delta * np.round(attacked_A4 / delta)                       # mreža za bit 0
    q1 = delta * (np.round((attacked_A4 - delta / 2) / delta) + 0.5)  # mreža za bit 1

    return (np.abs(attacked_A4 - q1) < np.abs(attacked_A4 - q0)).astype(int)


def amplitude_data(watermarked_signal, state):
    """
    Žig je binarni, pa se porede promjena A4 koeficijenata nastala
    kvantizacijom i promjena izmjerena nakon rekonstrukcije signala.
    """
    received_A4 = pywt.wavedec(watermarked_signal, WAVELET, level=LEVEL)[0]
    return (state["watermarked_A4"] - state["original_A4"],
            received_A4 - state["original_A4"],
            "Promjena A4 koeficijenta")


def figures(ecg_signal, watermarked_signal, state, fs):
    """Slika 6 (DWT), 7 (BWT) ili 8 (QB): razlika A4 koeficijenata."""
    diff_A4 = state["watermarked_A4"] - state["original_A4"]

    print(f"\n{NAME} - razlika A4 koeficijenata")
    print(f"Minimalna promjena A4: {np.min(diff_A4):.6f}")
    print(f"Maksimalna promjena A4: {np.max(diff_A4):.6f}")
    print(f"Maksimalna apsolutna promjena A4: {np.max(np.abs(diff_A4)):.6f}")

    plt.figure(figsize=(12, 4))
    plt.plot(diff_A4, color="red")
    plt.title("Razlika A4 koeficijenata prije i poslije QB watermarkinga")
    plt.xlabel("Indeks A4 koeficijenta")
    plt.ylabel("Razlika koeficijenata")
    save_figure(f"Slika_{FIGURE_NUMBER:02d}_razlika_A4_koeficijenata_{NAME}.png")
